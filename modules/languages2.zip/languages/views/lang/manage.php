<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>


<?php init_head();?>
<?php languages_add_head_component();?>
<?php function string_between_two_string($str, $starting_word, $ending_word)
{
    $subtring_start = strpos($str, $starting_word);
    //Adding the starting index of the starting word to
    //its length would give its ending index
    $subtring_start += strlen($starting_word); 
    //Length of our required sub string
    $size = strpos($str, $ending_word, $subtring_start) - $subtring_start; 
    // Return the substring from the index substring_start of length size
    return substr($str, $subtring_start, $size); 
}?>

<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="panel_s">
        <div class="panel-body">
          <h4 class="no-margin font-bold"><?php echo _l($title); ?>  traslation</h4>
          <hr />

          <div class="row">

            <?php foreach($content as $key => $value){ ?>

      
                <?php $value1 = preg_replace('/\s+/', ' ' , $value) ;$fruits_ar1 = explode('=', $value1 ); ?>
            <?php echo form_open('languages/changeline/'); ?>
            <div class="col-md-10">
              <div class="form-group" app-field-wrapper="value"><label for="value" class="control-label">
                <?php echo $fruits_ar1[0] ?>
                </label>
                <input type="text" id="value" name="value" class="form-control" value="<?php echo str_replace("'","",$fruits_ar1[1]) ?>">
              </div>
            </div>
            <div class="col-md-2 ">
              <input type="hidden" name="key" id="key" value="<?php echo string_between_two_string($fruits_ar1[0], "'", "'") ?>">
              <input type="hidden" name="lang" id="lang" value="<?php echo $title ?>">
                <!-- <input type="hidden" name="value" id="value"  value="<?php echo str_replace("'","",$fruits_ar1[1]) ?>"> -->
                  <div class="edit-d">
                    <div>
                    <input type="submit" name="submit" value="Edit" class="form-btn" >
                    </div>
                  </div>
            </div>
            <?php echo form_close();?>
            <?php }?>
          </div>
          
        </div>
      </div>
    </div>
  </div>
</div>


<!-- /.modal -->
<?php init_tail(); ?>
</body>
</html>
<?php require 'modules/accounting/assets/js/transfer/manage_js.php'; ?>
