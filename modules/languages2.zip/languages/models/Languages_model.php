<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Languages_model extends App_Model
{
    public function __construct()
    {
        parent::__construct();
    }
}